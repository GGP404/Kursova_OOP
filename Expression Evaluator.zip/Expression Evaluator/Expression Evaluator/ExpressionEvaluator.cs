﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Data;

namespace Expression_Evaluator
{
   
    public class ExpressionEvaluator
    {
        
        public double Evaluate(string expression)
        {
            if (string.IsNullOrWhiteSpace(expression))
                throw new ArgumentException("Вираз не може бути порожнім.");

            var table = new DataTable();
            // Опціонально: можна очистити налаштування безпеки
            table.Columns.Add("expression", typeof(string), expression);
            DataRow row = table.NewRow();
            table.Rows.Add(row);
            object value = row["expression"];
            return Convert.ToDouble(value);
        }
    }
}
